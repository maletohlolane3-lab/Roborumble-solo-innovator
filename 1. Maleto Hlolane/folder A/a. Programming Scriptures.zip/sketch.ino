#include <DHT.h>
#include <Wire.h>
#include <Adafruit_SSD1306.h>

#define DHTPIN 4
#define DHTTYPE DHT22
#define RED 26
#define GREEN 25
#define BUZZER1 27
#define BUZZER2 33
#define PIR 13

DHT dht(DHTPIN, DHTTYPE);
Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BUZZER1, OUTPUT);
  pinMode(BUZZER2, OUTPUT);
  pinMode(PIR, INPUT);
  dht.begin();
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
}

void loop() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  bool pir = digitalRead(PIR);
  
  String led = "";
  String b1 = "OFF";
  String b2 = "OFF";
  bool red = false;

  if (t < 18 || t > 30) {
    red = true;
    led = "RED ON";
    b1 = "SLOW";
    digitalWrite(RED, HIGH);
    digitalWrite(GREEN, LOW);
    digitalWrite(BUZZER1, HIGH); delay(300);
    digitalWrite(BUZZER1, LOW); delay(300);
  } else {
    led = "GREEN ON";
    b1 = "OFF";
    digitalWrite(GREEN, HIGH);
    digitalWrite(RED, LOW);
    digitalWrite(BUZZER1, LOW);
  }

  if (red && pir) {
    b2 = "FAST";
    for(int i=0;i<3;i++){
      digitalWrite(BUZZER2, HIGH); delay(100);
      digitalWrite(BUZZER2, LOW); delay(100);
    }
  } else {
    b2 = "OFF";
    digitalWrite(BUZZER2, LOW);
  }

  // OLED
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0,0);
  display.print("Temp: "); display.print(t,1); display.println(" C");
  display.print("Hum: "); display.print(h,0); display.println(" %");
  display.print("LED: "); display.println(led);
  display.print("Buzzer1: "); display.println(b1);
  display.print("Buzzer2: "); display.println(b2);
  display.print("PIR: "); display.println(pir ? "KID" : "CLEAR");
  display.display();
  delay(200);
}